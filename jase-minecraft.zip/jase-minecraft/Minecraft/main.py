from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

class VoxelWorld:
    def __init__(self):
        self.app = Ursina()
        self.grass_texture = load_texture('assets/grass2.png')
        self.sky_texture = load_texture('assets/sky.png')
        self.player = FirstPersonController()
        self.sky = Sky(texture = self.sky_texture)
        self.create_voxel_grid()

    def create_voxel_grid(self):
        for z in range(15):
            for x in range(15):
                Voxel(position = (x, 0, z), texture = self.grass_texture)

    def run(self):
        self.app.run()

class Sky(Entity):
    def __init__(self, texture = None):
        super().__init__(
            parent = scene,
            model = 'sphere',
            scale = 150,
            texture = texture,
            double_sided = True,
        )

class Voxel(Button):
    def __init__(self, position = (0, 0, 0), texture = None):
        super().__init__(
            parent = scene,
            position = position,
            model = 'cube',
            origin_y = 5,
            texture = texture,
            color = color.color(0, 0, 255),
            highlight_color = color.lime,
        )

    def input(self, key):
        if self.hovered:
            if key == 'right mouse down':
                new_position = self.position + mouse.normal
                voxel = Voxel(position = new_position, texture = self.texture)
            if key == 'left mouse down':
                destroy(self)

if __name__ == "__main__":
    world = VoxelWorld()
    world.run()
